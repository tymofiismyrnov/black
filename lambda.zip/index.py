import base64
import pprint
import boto3
from datetime import datetime
import inspect


def lambda_handler(event, context):
    ec2 = boto3.resource(service_name='ec2')
    for instance in ec2.instances.all():
        running = (instance.state['Name']).lower() == 'running'
        response = instance.describe_attribute(Attribute='userData')
        if response.get('UserData') and running:
            userData = base64.b64decode(response['UserData']['Value'])
            break

    ec2 = boto3.client('ec2')
    filters = [
        {
            'Name': 'instance-state-name',
            'Values': ['running']
        }
    ]
    response = ec2.describe_instances(Filters=filters)

    if len(response) < 15:
        source_instance = response['Reservations'][0]['Instances'][0]

        # Define parameters for launching a new instance based on the source instance
        launch_parameters = {
            'MaxCount': 1,
            'MinCount': 1,
            'ImageId': source_instance['ImageId'],
            'InstanceType': source_instance['InstanceType'],
            'SecurityGroupIds': [sg['GroupId'] for sg in source_instance['SecurityGroups']],
            'SubnetId': source_instance['SubnetId'],
            'TagSpecifications': [
                {
                    'ResourceType': 'instance',
                    'Tags': [{
                        'Key': 'Name',
                        'Value': f'Script_instance_{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}'
                    }]
                }
            ],
            'UserData': userData
        }
        if source_instance.get('KeyName'):
            launch_parameters['KeyName'] = source_instance.get('KeyName')

        # Launch a new EC2 instance based on the source instance's configuration
        response = ec2.run_instances(**launch_parameters)

        # Extract the ID of the newly created instance
        new_instance_id = response['Instances'][0]['InstanceId']
        print(f"Created a new instance with ID: {new_instance_id}")
        return 0
    else:
        print("No running instances found matching the filters.")
        return 1
